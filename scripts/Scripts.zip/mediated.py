# mediated.py
import pandas as pd
import numpy as np

from config import DATA_PROC, MEDIATED_PATH
from data_load import load_imdb_raw, load_movielens_raw, load_tmdb_raw
from utils import (
    normalize_title, normalize_genres,
    scale_rating_to_10, extract_year_from_title,
    extract_year_from_date
)

def map_imdb_to_mediated(df_imdb: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, row in df_imdb.iterrows():
        try:
            year = int(row["startYear"])
        except Exception:
            year = np.nan
        rows.append({
            "movie_temp_id": f"imdb:{row['tconst']}",
            "source": "imdb",
            "source_id": row["tconst"],
            "title_norm": normalize_title(row["primaryTitle"]),
            "year": year,
            "genres_norm": normalize_genres(row["genres"], "imdb"),
            "rating_value": scale_rating_to_10(row["averageRating"], "imdb"),
            "rating_count": row["numVotes"],
            "popularity": np.nan,
            "budget": np.nan,
            "revenue": np.nan
        })
    return pd.DataFrame(rows)


def map_movielens_to_mediated(df_ml_movies: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, row in df_ml_movies.iterrows():
        year = extract_year_from_title(row["title"])
        rows.append({
            "movie_temp_id": f"ml:{row['movieId']}",
            "source": "movielens",
            "source_id": row["movieId"],
            "title_norm": normalize_title(row["title"]),
            "year": year,
            "genres_norm": normalize_genres(row["genres"], "movielens"),
            "rating_value": scale_rating_to_10(row["rating_mean"], "movielens"),
            "rating_count": row["rating_count"],
            "popularity": np.nan,
            "budget": np.nan,
            "revenue": np.nan
        })
    return pd.DataFrame(rows)


def map_tmdb_to_mediated(df_tmdb: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, row in df_tmdb.iterrows():
        year = extract_year_from_date(row["release_date"])
        rows.append({
            "movie_temp_id": f"tmdb:{row['id']}",
            "source": "tmdb",
            "source_id": row["id"],
            "title_norm": normalize_title(row["title"]),
            "year": year,
            "genres_norm": normalize_genres(row["genre_names"], "tmdb"),
            "rating_value": scale_rating_to_10(row["vote_average"], "tmdb"),
            "rating_count": row["vote_count"],
            "popularity": row["popularity"],
            "budget": np.nan,
            "revenue": np.nan
        })
    return pd.DataFrame(rows)


def build_mediated_table() -> pd.DataFrame:
    """Build mediated table from all three sources and save to CSV."""
    imdb_raw_path = DATA_PROC / "imdb_movies_raw.csv"
    ml_movies_raw_path = DATA_PROC / "movielens_movies_raw.csv"

    if imdb_raw_path.exists():
        df_imdb = pd.read_csv(imdb_raw_path)
    else:
        df_imdb = load_imdb_raw()

    if ml_movies_raw_path.exists():
        df_ml_movies = pd.read_csv(ml_movies_raw_path)
    else:
        df_ml_movies, _ = load_movielens_raw()

    df_tmdb = load_tmdb_raw()

    imdb_m = map_imdb_to_mediated(df_imdb)
    ml_m = map_movielens_to_mediated(df_ml_movies)
    tmdb_m = map_tmdb_to_mediated(df_tmdb)

    mediated = pd.concat([imdb_m, ml_m, tmdb_m], ignore_index=True)
    mediated.to_csv(MEDIATED_PATH, index=False)
    print(f"[Mediated] Saved {len(mediated)} rows -> {MEDIATED_PATH}")
    return mediated
