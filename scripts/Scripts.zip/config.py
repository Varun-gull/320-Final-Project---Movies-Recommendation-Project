# config.py
import os
from pathlib import Path
from dotenv import load_dotenv

# Base directory of project
BASE_DIR = Path(__file__).resolve().parent

# Raw and processed data directories
DATA_RAW = BASE_DIR / "data_raw"
DATA_PROC = BASE_DIR / "data_processed"
DATA_PROC.mkdir(exist_ok=True, parents=True)

# IMDb files
IMDB_BASICS = DATA_RAW / "title.basics.tsv.gz"
IMDB_RATINGS = DATA_RAW / "title.ratings.tsv.gz"

# MovieLens files
ML_MOVIES = DATA_RAW / "movielens" / "movies.csv"
ML_RATINGS = DATA_RAW / "movielens" / "ratings.csv"

# TMDb intermediate file
TMDB_MOVIES_RAW = DATA_PROC / "tmdb_movies_raw.csv"

# Mediated / integrated output files
MEDIATED_PATH = DATA_PROC / "mediated_movies_all_sources.csv"
INTEGRATED_MOVIES_PATH = DATA_PROC / "integrated_movies.csv"
ML_RATINGS_INTEGRATED_PATH = DATA_PROC / "movielens_ratings_integrated.csv"

# Load env variables
load_dotenv()
TMDB_API_KEY = os.getenv("TMDB_API_KEY")
