# data_load.py
import time
import pandas as pd
import requests

from config import (
    IMDB_BASICS, IMDB_RATINGS,
    ML_MOVIES, ML_RATINGS,
    TMDB_MOVIES_RAW, DATA_PROC, TMDB_API_KEY
)

def load_imdb_raw():
    """Load IMDb basics + ratings from TSV."""
    if not IMDB_BASICS.exists() or not IMDB_RATINGS.exists():
        raise FileNotFoundError("IMDb TSVs not found in data_raw/. Download them first.")

    basics = pd.read_csv(IMDB_BASICS, sep="\t", na_values="\\N", low_memory=False)
    ratings = pd.read_csv(IMDB_RATINGS, sep="\t", na_values="\\N", low_memory=False)

    basics = basics[basics["titleType"] == "movie"]
    df = basics.merge(ratings, on="tconst", how="left")
    df = df[["tconst", "primaryTitle", "startYear", "genres", "averageRating", "numVotes"]]

    out_path = DATA_PROC / "imdb_movies_raw.csv"
    df.to_csv(out_path, index=False)
    print(f"[IMDb] Saved {len(df)} movies -> {out_path}")
    return df


def load_movielens_raw():
    """Load MovieLens movies + ratings from CSV."""
    if not ML_MOVIES.exists() or not ML_RATINGS.exists():
        raise FileNotFoundError("MovieLens CSVs not found in data_raw/movielens/.")

    movies = pd.read_csv(ML_MOVIES)
    ratings = pd.read_csv(ML_RATINGS)

    movie_stats = ratings.groupby("movieId").agg(
        rating_mean=("rating", "mean"),
        rating_count=("rating", "count")
    ).reset_index()

    movies_agg = movies.merge(movie_stats, on="movieId", how="left")

    movies_agg.to_csv(DATA_PROC / "movielens_movies_raw.csv", index=False)
    ratings.to_csv(DATA_PROC / "movielens_ratings_raw.csv", index=False)

    print(f"[MovieLens] Saved {len(movies_agg)} movies and {len(ratings)} ratings")
    return movies_agg, ratings


def tmdb_get(endpoint: str, params=None):
    """Helper for TMDb GET requests."""
    if params is None:
        params = {}
    if TMDB_API_KEY is None:
        raise RuntimeError("TMDB_API_KEY not set in environment/.env")
    params["api_key"] = TMDB_API_KEY
    url = f"https://api.themoviedb.org/3/{endpoint}"
    r = requests.get(url, params=params)
    r.raise_for_status()
    return r.json()


def load_tmdb_raw(max_pages=5):
    """Load a sample of popular TMDb movies via API and save to CSV."""
    if TMDB_MOVIES_RAW.exists():
        print(f"[TMDb] Using existing {TMDB_MOVIES_RAW}")
        return pd.read_csv(TMDB_MOVIES_RAW)

    movies = []
    for page in range(1, max_pages + 1):
        data = tmdb_get("movie/popular", params={"page": page})
        movies.extend(data["results"])
        print(f"[TMDb] Fetched popular page {page}")
        time.sleep(0.25)

    df = pd.DataFrame(movies)

    # Get genre mapping
    genre_data = tmdb_get("genre/movie/list")
    genre_map = {g["id"]: g["name"] for g in genre_data["genres"]}

    def map_genres(genre_ids):
        if not isinstance(genre_ids, list):
            return []
        return [genre_map.get(gid, "") for gid in genre_ids]

    df["genre_names"] = df["genre_ids"].apply(map_genres)

    df = df[[
        "id",
        "title",
        "release_date",
        "genre_names",
        "vote_average",
        "vote_count",
        "popularity"
    ]]

    df.to_csv(TMDB_MOVIES_RAW, index=False)
    print(f"[TMDb] Saved {len(df)} movies -> {TMDB_MOVIES_RAW}")
    return df
